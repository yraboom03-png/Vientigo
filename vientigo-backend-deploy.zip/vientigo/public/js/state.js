export const state = {
  token: localStorage.getItem('vientigo_token'),
  user: null, socket: null, chats: [], activeChatId: null, messages: [], gifts: [], replyingTo: null
};
export const avatars = ['👤', '😎', '🤖', '👽', '🐱', '🦊', '🐼', '🦁', '🔥', '💎', '🚀', '👑'];