import 'dotenv/config';
import pg from 'pg';
const { Pool } = pg;

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY, username VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL, display_name VARCHAR(255) NOT NULL,
      avatar VARCHAR(10) DEFAULT '👤', balance BIGINT DEFAULT 50, last_bonus_at BIGINT DEFAULT 0, created_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chats (
      id SERIAL PRIMARY KEY, type VARCHAR(50) NOT NULL DEFAULT 'direct', name VARCHAR(255), created_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chat_members (
      chat_id INTEGER REFERENCES chats(id) ON DELETE CASCADE, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY (chat_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS messages (
      id SERIAL PRIMARY KEY, chat_id INTEGER REFERENCES chats(id) ON DELETE CASCADE,
      sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE, content TEXT NOT NULL,
      message_type VARCHAR(50) DEFAULT 'text', gift_id INTEGER, reply_to INTEGER, is_read BOOLEAN DEFAULT FALSE, created_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS gifts (
      id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL, price INTEGER NOT NULL, icon VARCHAR(10) NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, created_at);
  `);

  const giftsCount = await pool.query('SELECT COUNT(*) FROM gifts');
  if (parseInt(giftsCount.rows[0].count) === 0) {
    await pool.query(`INSERT INTO gifts (name, price, icon) VALUES ('Роза', 10, '🌹'), ('Сердце', 20, '❤️'), ('Медведь', 50, '🧸'), ('Ракета', 100, '🚀'), ('Корона', 500, '👑'), ('Бриллиант', 1000, '💎');`);
  }
}